package com.starhotel.mngt;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;

import javax.swing.*;


public class NCDialog extends JDialog implements ActionListener{
	
	private JTextField custIdentification;
	private JTextField custName;
	private JTextField custStreet;
	private JTextField custSuburb;
	private JTextField custState;
	private JTextField custPostcode;
	private JButton createCustomer;
	private JRadioButton rbMale, rbFemale;

	int customerId;
	String customerIdentification;
	String customerName;
	String customerStreet;
	String customerSuburb;
	String customerState;
	String customerPostcode;
	String customerGender;
	
	public NCDialog() {
		add(getPanel());
		this.setTitle("New Customer");
		this.setModal(true);
		this.setSize(400,250);
	    this.setLocationRelativeTo(this);
    	this.setVisible(true); 
	}
	
	//Entry form for create new customer
	public JPanel getPanel(){
		
		JPanel panel = new JPanel();
		panel.setLayout(new GridBagLayout());
      
        GridBagConstraints left = new GridBagConstraints();
        left.anchor = GridBagConstraints.EAST;
        
        GridBagConstraints right = new GridBagConstraints();
        right.weightx = 2.0;
        right.fill = GridBagConstraints.HORIZONTAL;
        right.gridwidth = GridBagConstraints.REMAINDER;
        
        GridBagConstraints down = new GridBagConstraints();
        down.fill = GridBagConstraints.HORIZONTAL;
        down.gridx = 1;
        down.gridy = 10;
        down.weightx = 1.0; 
        down.weighty = 0.0;
   		
		//Add customer details field 
		JLabel lblIdentification = new JLabel("Identification: ");
		panel.add(lblIdentification,left);
		
		custIdentification = new JTextField(10);
		panel.add(custIdentification,right);
		
		panel.add(lblIdentification, left);
	    panel.add(custIdentification, right);
	    
		JLabel lblName = new JLabel("Name: ");
		panel.add(lblName,left);
		
		custName = new JTextField(10);
		panel.add(custName,right);
		 
		JLabel lblStreet = new JLabel("Street: ");
		panel.add(lblStreet,left);
		
		custStreet = new JTextField(10);
		panel.add(custStreet,right);
		
		JLabel lblSuburb = new JLabel("Suburb: ");
		panel.add(lblSuburb,left);
		
		custSuburb = new JTextField(10);
		panel.add(custSuburb,right);
		
		JLabel lblState = new JLabel("State: ");
		panel.add(lblState,left);
		
		custState = new JTextField(10);
		panel.add(custState,right);
		
		JLabel lblPostcode = new JLabel("Postcode: ");
		panel.add(lblPostcode,left);
		
		custPostcode = new JTextField(10);
		panel.add(custPostcode,right);
		
		
		JLabel lblGender = new JLabel("Gender");
		panel.add(lblGender);
		
		Box horizontalBox = new Box(BoxLayout.X_AXIS);
		rbMale = new JRadioButton("Male");
		horizontalBox.add(rbMale);
		rbMale.setSelected(true);		
		rbFemale = new JRadioButton("Female");
		horizontalBox.add(rbFemale);
		panel.add(horizontalBox);
			       
		ButtonGroup bg = new ButtonGroup();
		bg.add(rbMale);
		bg.add(rbFemale);
		
		panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		
		createCustomer = new JButton("Create");
		createCustomer.addActionListener(this);
		panel.add(createCustomer,down);
		 
		return panel;

	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		customerIdentification = custIdentification.getText();
		customerName = custName.getText();
		customerStreet = custStreet.getText();
		customerSuburb = custSuburb.getText();
		customerState = custState.getText();
		customerPostcode = custPostcode.getText();
		customerGender = (rbMale.isSelected())?"Male":"Female";
		
		Customer customer = new Customer();
		customer.setIdentification(customerIdentification);
		customer.setName(customerName);
		customer.setStreet(customerStreet);
		customer.setSuburb(customerSuburb);
		customer.setState(customerState);
		customer.setPostcode(customerPostcode);
		customer.setGender(customerGender);
		CustomerManagerImpl cdl = new CustomerManagerImpl();
		
		try {
			customerId = cdl.createCustomer(customer);
			JOptionPane.showMessageDialog(this,
					"Customer "+ customerName +" was successfully created.",
				    "Success.",				    
				    JOptionPane.INFORMATION_MESSAGE);
			
			this.dispose();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(this,				 
				    "Customer was not created.",
				    "ERROR.",
				    JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
}
