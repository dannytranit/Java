package com.starhotel.mngt;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

public class LCPanel extends JPanel implements ActionListener, ListSelectionListener{
	private JTable table;
	private JButton newC, delete,edit,markDefaulter,viewMoreDetails,search;
	private TableModel tableModel;
    private String selectedId = null;
    private int selectedRow;
   // private List<String> columns = new ArrayList<String>();
	//private List<String[]> values = new ArrayList<String[]>();
    
	public LCPanel() throws SQLException {		 
		getPanel();
	}
	
	
	public JPanel getPanel() throws SQLException {
		setLayout(new BorderLayout());
		Box horizontalBox = new Box(BoxLayout.X_AXIS);
		newC = new JButton("New");
		newC.addActionListener(this);
		
		edit = new JButton("Edit");
		edit.setEnabled(false);
		edit.addActionListener(this);
		
		delete = new JButton("Delete");
		delete.addActionListener(this);
		delete.setEnabled(false);
		
		markDefaulter = new JButton("Mark Defaulter");
		markDefaulter.addActionListener(this);
		markDefaulter.setEnabled(false);
		
		viewMoreDetails = new JButton("View More Details");
		viewMoreDetails.addActionListener(this);
		viewMoreDetails.setEnabled(false);
		
		search = new JButton("Advanced Search");
		search.addActionListener(this);
		search.setEnabled(true);
		
		horizontalBox.add(newC);
		horizontalBox.add(edit);
		horizontalBox.add(delete);
		horizontalBox.add(markDefaulter);
		horizontalBox.add(viewMoreDetails);
		horizontalBox.add(search);
		
		add(horizontalBox,BorderLayout.NORTH);
		
		List<String> columns = new ArrayList<String>();
		List<String[]> values = new ArrayList<String[]>();
		columns.add("ID");
		columns.add("Identification");
	    columns.add("Name");
	    columns.add("Street");
	    columns.add("Suburb");
	    columns.add("State");
	    columns.add("Postcode");
	    columns.add("Gender");
	    columns.add("Defaulter");
	     
	    CustomerManagerImpl cdl = new CustomerManagerImpl();
		List<Customer> customers = cdl.getAllCustomers();
		 //display all customers on a listing
		 for (Customer c: customers) {
           values.add(new String[] {c.getId()+"",c.getIdentification(), c.getName(),
           		                 c.getStreet(),c.getSuburb(),c.getState(),c.getPostcode(),c.getGender(),c.getDefaulter()});
		 }
        tableModel = new DefaultTableModel(values.toArray(new Object[][] {}), columns.toArray()){
	   
      	@Override
 	    public boolean isCellEditable(int row, int column) {
	       //none is editable
	       return column == -1;
	    }};        
	    table = new JTable(tableModel);
        table.setCellSelectionEnabled(true);
        
      
        ListSelectionModel cellSelectionModel = table.getSelectionModel();
        cellSelectionModel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        cellSelectionModel.addListSelectionListener(this);
        JScrollPane jsp = new JScrollPane(table);
        jsp.setPreferredSize(new Dimension(450,600));
        add(jsp,BorderLayout.CENTER);
        
       
        return this;
   
	}
    

	@Override
	public void actionPerformed(ActionEvent ae) {
		int selectedOption;
		
		//Delete the selected record from the list
		if(ae.getSource() == delete){	
			selectedOption = JOptionPane.showConfirmDialog(null, 
                    "Do you want to delete this customer?", 
                    "Confirmation", 
                    JOptionPane.YES_NO_OPTION); 
			
			if (selectedOption == JOptionPane.YES_OPTION) {
			
				selectedRow = table.getSelectedRows()[0];
				selectedId = (String) table.getValueAt(selectedRow, 0); 
				int customerId = Integer.parseInt(selectedId);
				CustomerManagerImpl cdl = new CustomerManagerImpl();
				boolean success = cdl.deleteCustomer(customerId);
				
				if(success){
					((DefaultTableModel) tableModel).removeRow(selectedRow);
					edit.setEnabled(false);
					delete.setEnabled(false);
					markDefaulter.setEnabled(false);
					viewMoreDetails.setEnabled(false);
				}
			}//end confirmation
			
		}
		
		//Edit the selected record
		if(ae.getSource() == edit){ 
			selectedRow = table.getSelectedRows()[0];
			selectedId = (String) table.getValueAt(selectedRow, 0); 
			int customerId = Integer.parseInt(selectedId);
			Customer customer = new Customer();
			String customerIdentification = (String) table.getValueAt(selectedRow, 1);
			String customerName = (String) table.getValueAt(selectedRow, 2);
			String customerStreet = (String) table.getValueAt(selectedRow, 3);
			String customerSuburb = (String) table.getValueAt(selectedRow, 4);
			String customerState = (String) table.getValueAt(selectedRow, 5);
			String customerPostcode = (String) table.getValueAt(selectedRow, 6);
			String customerGender = (String) table.getValueAt(selectedRow, 7);
			String customerDefaulter = (String) table.getValueAt(selectedRow, 8);
			
			UCDialog ucd = new UCDialog(customerId,customerIdentification, customerName, customerStreet,customerSuburb,customerState,customerPostcode, customerGender);  
			
			tableModel.setValueAt(ucd.customerIdentification, selectedRow, 1);
			tableModel.setValueAt(ucd.customerName, selectedRow, 2);
			tableModel.setValueAt(ucd.customerStreet, selectedRow, 3);
			tableModel.setValueAt(ucd.customerSuburb, selectedRow, 4);
			tableModel.setValueAt(ucd.customerState, selectedRow, 5);
			tableModel.setValueAt(ucd.customerPostcode, selectedRow, 6);
			tableModel.setValueAt(ucd.customerGender, selectedRow, 7);
			
		}
		
		//add new customer record: call NCDialog then refresh the LCPanel
		if(ae.getSource() == newC){    
		    NCDialog ncd = new NCDialog();  
		    Vector<String> values = new Vector<String>();
		    values.add(String.valueOf(ncd.customerId));
		    values.add(ncd.customerIdentification);
		    values.add(ncd.customerName);
		    values.add(ncd.customerStreet);
		    values.add(ncd.customerSuburb);
		    values.add(ncd.customerState);
		    values.add(ncd.customerPostcode);
		    values.add(ncd.customerGender);
		    ((DefaultTableModel) tableModel).addRow(values);
		}
		
		//markDefaulter the selected record from the list
		if(ae.getSource() == markDefaulter){	
			selectedOption = JOptionPane.showConfirmDialog(null, 
                    "Do you want to mark this customer as a defaulter?", 
                    "Confirmation", 
                    JOptionPane.YES_NO_OPTION); 
			
			if (selectedOption == JOptionPane.YES_OPTION) {
				selectedRow = table.getSelectedRows()[0];
				selectedId = (String) table.getValueAt(selectedRow, 0); 
				int customerId = Integer.parseInt(selectedId);
				CustomerManagerImpl cdl = new CustomerManagerImpl();
				boolean success = cdl.markDefaulter(customerId);
				if(success){
					((DefaultTableModel) tableModel).setValueAt( Customer.DEFAULTER_YES, selectedRow, 8);
					edit.setEnabled(false);
					delete.setEnabled(false);
					markDefaulter.setEnabled(false);
					viewMoreDetails.setEnabled(false);
				}
			}//end if confirmation
			
		}
		
		//View More Details the selected record from the list
		if(ae.getSource() == viewMoreDetails){	
			selectedRow = table.getSelectedRows()[0];
			selectedId = (String) table.getValueAt(selectedRow, 0); 
			int customerId = Integer.parseInt(selectedId);
			Customer customer = new Customer();
			String customerIdentification = (String) table.getValueAt(selectedRow, 1);
			String customerName = (String) table.getValueAt(selectedRow, 2);
			String customerStreet = (String) table.getValueAt(selectedRow, 3);
			String customerSuburb = (String) table.getValueAt(selectedRow, 4);
			String customerState = (String) table.getValueAt(selectedRow, 5);
			String customerPostcode = (String) table.getValueAt(selectedRow, 6);
			String customerGender = (String) table.getValueAt(selectedRow, 7);
			String customerDefaulter = (String) table.getValueAt(selectedRow, 8);
			
			VCDialog vcd = new VCDialog(customerId,customerIdentification, customerName, customerStreet,customerSuburb,customerState,customerPostcode, customerGender,customerDefaulter);  
			
			tableModel.setValueAt(vcd.customerIdentification, selectedRow, 1);
			tableModel.setValueAt(vcd.customerName, selectedRow, 2);
			tableModel.setValueAt(vcd.customerStreet, selectedRow, 3);
			tableModel.setValueAt(vcd.customerSuburb, selectedRow, 4);
			tableModel.setValueAt(vcd.customerState, selectedRow, 5);
			tableModel.setValueAt(vcd.customerPostcode, selectedRow, 6);
			tableModel.setValueAt(vcd.customerGender, selectedRow, 7);
			
		}//end if
		
		//Advanced Search 
		if(ae.getSource() == search){ 
			SCDialog scd = new SCDialog();
			
			List<Customer> searchCustomers = scd.getCustomerList();
			if (searchCustomers != null){
		    //reset existing data displayed on table
			
				((DefaultTableModel) tableModel).setRowCount(0);
	   
			    //populate the data with new data
			    for (Customer c: searchCustomers) {
			    	
					 Vector<String> values = new Vector<String>();
					    values.add(String.valueOf(c.getId()));
					    values.add(c.getIdentification());
					    values.add(c.getName());
					    values.add(c.getStreet());
					    values.add(c.getSuburb());
					    values.add(c.getState());
					    values.add(c.getPostcode());
					    values.add(c.getGender());
					    values.add(c.getDefaulter());
					    ((DefaultTableModel) tableModel).addRow(values);
			    }
			}
		}//end if
				
	}

	@Override
	public void valueChanged(ListSelectionEvent arg0) {
		edit.setEnabled(true);
		delete.setEnabled(true);	
		markDefaulter.setEnabled(true);	
		viewMoreDetails.setEnabled(true);
	}
		
	
}
