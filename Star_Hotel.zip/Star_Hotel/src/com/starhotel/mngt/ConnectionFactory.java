package com.starhotel.mngt;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class ConnectionFactory {
	private static final String SERVER= "localhost";
	private static final String DATABASE_NAME = "star_hotel";
	private static final String USER = "root";
	private static final String PASSWORD = "12345";
    
    public static final String URL = "jdbc:mysql://" + SERVER + ":3306/" + DATABASE_NAME;
    public static final String DRIVER_CLASS = "com.mysql.jdbc.Driver";
    
    //static reference to itself
    private static ConnectionFactory instance = new ConnectionFactory();
    
    private ConnectionFactory()
    {
        try {
            Class.forName(DRIVER_CLASS);
        }
        catch(ClassNotFoundException e)
        {
            e.printStackTrace();
        }
    }

    
    public static ConnectionFactory getInstance()
    {
        if(instance == null) {
            instance = new ConnectionFactory();
        }
        return instance;
         
    }
    
    public Connection getConnection() throws SQLException,ClassNotFoundException{
    	Connection connection = DriverManager.getConnection(URL,USER,PASSWORD);
    	return connection;
    }
    
    
    
}
		


