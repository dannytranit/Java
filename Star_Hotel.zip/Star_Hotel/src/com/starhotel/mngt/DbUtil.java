package com.starhotel.mngt;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
 
public class DbUtil {
	 
    public static void close(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                /*log or print or ignore*/
            }
        }
    }
 
    public static void close(Statement statement) {
        if (statement != null) {
            try {
                statement.close();
            } catch (SQLException e) {
                /*log or print or ignore*/
            }
        }
    }
 
    public static void close(ResultSet resultSet) {
        if (resultSet != null) {
            try {
                resultSet.close();
            } catch (SQLException e) {
                /*log or print or ignore*/
            }
        }
    }
    
    public static void createTables() throws Exception{
    	Connection conn = null;
		Statement stmt = null;
		String sql = null;
	    try{
	    	conn = ConnectionFactory.getInstance().getConnection();
	    	conn.setAutoCommit(false);
	    	
	    	stmt = conn.createStatement();
	    	
	    	System.out.println("Drop customer table");
	    	
	    	sql = "DROP TABLE `customer`;";
	    	stmt.executeUpdate(sql);
	    	
	    	System.out.println("Create customer table");
	    	
	    	sql =  "CREATE TABLE `customer` (" +
	    			  "`id` int(11) NOT NULL AUTO_INCREMENT," +
	    			  "`identification` varchar(50) DEFAULT NULL," +
	    			  "`name` varchar(255) DEFAULT NULL," +
	    			  "`gender` varchar(10) DEFAULT NULL," +
	    			  "`street` varchar(100) DEFAULT NULL," +
	    			  "`suburb` varchar(50) DEFAULT NULL," +
	    			  "`state` varchar(10) DEFAULT NULL," +
	    			  "`postcode` varchar(4) DEFAULT NULL," +
	    			  "`defaulter` varchar(3) DEFAULT NULL," +
	    			  "PRIMARY KEY (`id`)" +
	    			");";
	    	stmt.executeUpdate(sql);
	    	
	    	System.out.println("Drop booking table");
	    	sql = "DROP TABLE `booking`;";
	    	
	    	System.out.println("Create booking table");
	    	stmt.executeUpdate(sql);
	    	sql = "CREATE TABLE `booking` (" +
	    			  "`booking_id` char(9) NOT NULL," +
	    			  "`customer_id` int(11) NOT NULL," +
	    			  "`room_number` int(11) NOT NULL," +
	    			  "`arrival` date DEFAULT NULL," +
	    			  "`departure` date DEFAULT NULL," +
	    			  "`total_cost` double DEFAULT NULL," +
	    			  "PRIMARY KEY (`booking_id`)" +
	    			");";
	    	stmt.executeUpdate(sql);
	    	
	        System.out.println("Created tables in given database...");
	        
	        conn.commit();
	    }
	    catch (SQLException e) {
	    	 System.out.println("Error:" + e.getMessage());
        }
	    catch(ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        finally 
        {
        	conn.rollback();
            DbUtil.close(stmt);
            DbUtil.close(conn);
        }
    }//createTables
}
 
