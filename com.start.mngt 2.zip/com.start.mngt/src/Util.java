public class Util {
	public static String getVal(String val) {
        String result=null;
        try {
        	
        	if(val != null && !val.isEmpty()){
        		result = val;
    		}
        	else
    		{
        		result = "";
    		}
           
        } catch (Exception e) {
            /*log or print or ignore*/
        }
        return result;
    }
}
