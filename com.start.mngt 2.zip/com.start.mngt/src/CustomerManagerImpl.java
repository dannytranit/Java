import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
 
public class CustomerManagerImpl implements CustomerManager{
	private Connection connection;
    private Statement statement;
    private PreparedStatement preparedStatement;
    private static final String DELETE = "DELETE FROM customer WHERE id=?";
    private static final String FIND_ALL = "SELECT * FROM customer ORDER BY id";
    private static final String FIND_BY_ID = "SELECT * FROM Customer WHERE id=?";
    private static final String INSERT = "INSERT INTO customer (identification,name, gender,street,suburb,state,postcode) VALUES (?,?, ?, ?, ?, ?, ?)";
    private static final String UPDATE = "UPDATE customer SET identification=?, name=?, gender=?, street=?, suburb=?, state=?, postcode=? WHERE id=?";
    private static final String MARK_DEFAULTER = "UPDATE customer SET defaulter=? WHERE id=?";
    
	public ArrayList<Customer> getAllCustomers() throws SQLException {
	        ArrayList<Customer> list = new ArrayList<Customer>();
	        Customer customer = null;
	        ResultSet rs = null;
	        try {
	          
	        	connection = ConnectionFactory.getInstance().getConnection();
	            statement = connection.createStatement();
	            rs = statement.executeQuery(FIND_ALL);
	 
	            while (rs.next()) {
	                customer = new Customer();
	                customer.setId(rs.getInt("id"));
	                customer.setIdentification(rs.getString("identification")) ;
	                customer.setName(rs.getString("name")) ;
	                customer.setGender(rs.getString("gender"));
	                customer.setStreet(rs.getString("street"));
	                customer.setSuburb(rs.getString("suburb"));
	                customer.setState(rs.getString("state"));
	                customer.setPostcode(rs.getString("postcode"));
	                customer.setDefaulter(rs.getString("defaulter"));
	                
	                System.out.println(customer.getName());
	                
	                //add each customer to the list
	                list.add(customer);
	            }
	        } 
	        catch(ClassNotFoundException e)
	        {
	            e.printStackTrace();
	        }
	        finally {
	            DbUtil.close(rs);
	            DbUtil.close(statement);
	            DbUtil.close(connection);
	        }
	        return list;
	}
	
	
	
	@Override
	public Customer getCustomerByID(int id) throws SQLException {
        Customer customer = null;
        ResultSet rs = null;
        try {
            connection = ConnectionFactory.getInstance().getConnection();
            preparedStatement  = connection.prepareStatement(FIND_BY_ID);
            preparedStatement.setInt(1, id); // Set 1st WHERE to int
            rs = preparedStatement.executeQuery();
    
             if (rs.next()) {
                customer = new Customer();
                customer.setId(rs.getInt("id"));
                customer.setIdentification(rs.getString("identification")) ;
                customer.setName(rs.getString("name")) ;
                customer.setGender(rs.getString("gender"));
                customer.setStreet(rs.getString("street"));
                customer.setSuburb(rs.getString("suburb"));
                customer.setState(rs.getString("state"));
                customer.setPostcode(rs.getString("postcode"));
                customer.setDefaulter(rs.getString("defaulter"));
            }
        } 
        catch(ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        finally {
            DbUtil.close(rs);
            DbUtil.close(statement);
            DbUtil.close(connection);
        }
        return customer;
}
	
	@Override
	public boolean updateCustomer(Customer customer) {
		try {
			
			 connection = ConnectionFactory.getInstance().getConnection();
			 preparedStatement = connection.prepareStatement(UPDATE);
			 preparedStatement.setString(1, customer.getIdentification());
			 preparedStatement.setString(2, customer.getName());
			 preparedStatement.setString(3, customer.getGender());
			 preparedStatement.setString(4, customer.getStreet());
			 preparedStatement.setString(5, customer.getSuburb());
			 preparedStatement.setString(6, customer.getState());
			 preparedStatement.setString(7, customer.getPostcode());
			 preparedStatement.setInt(8, customer.getId());  
			 preparedStatement.executeUpdate();
		} 
		catch (SQLException e) {
        	return false;
        }
	    catch(ClassNotFoundException e)
        {
            e.printStackTrace();
        }
		finally {
            DbUtil.close(preparedStatement);
            DbUtil.close(connection);
        }
		return true;
	}

	@Override
	public boolean deleteCustomer(int id) {
		try {
			
			connection = ConnectionFactory.getInstance().getConnection();
            preparedStatement  = connection.prepareStatement(DELETE); 
            preparedStatement.setInt(1, id); 
            preparedStatement.executeUpdate();
        } 
		catch (SQLException e) {
           return false;            
        }
		catch(ClassNotFoundException e)
        {
            e.printStackTrace();
        }
		finally {
            DbUtil.close(preparedStatement);
            DbUtil.close(connection);
        }
		return true;
	}

	@Override
	public int createCustomer(Customer customer) throws SQLException {
		try {
		
			connection = ConnectionFactory.getInstance().getConnection();
			preparedStatement  = connection.prepareStatement(INSERT, Statement.RETURN_GENERATED_KEYS);
			preparedStatement.setString(1, customer.getIdentification());
			preparedStatement.setString(2, customer.getName());
			preparedStatement.setString(3, customer.getGender());
			preparedStatement.setString(4, customer.getStreet());
			preparedStatement.setString(5, customer.getSuburb());
			preparedStatement.setString(6, customer.getState());
			preparedStatement.setString(7, customer.getPostcode());
			preparedStatement.executeUpdate();
			ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
			if(generatedKeys.next())
				return(generatedKeys.getInt(1))	;
			return -1;
		}
		catch(ClassNotFoundException e)
	        {
	            return -1;
	        }
		finally {
            DbUtil.close(preparedStatement);
            DbUtil.close(connection);
        }
	}	

	@Override
	public ArrayList<Customer> getCustomerByCriteria(Customer custCriteria) throws SQLException {
		   ResultSet rs = null;
	       Customer customer = null;
	       String sql = null;
	       ArrayList<Customer> list = new ArrayList<Customer>();
	       try {
	            connection = ConnectionFactory.getInstance().getConnection();
	        	sql = "select * from customer where true";
	        	
	            if (custCriteria.getId()>0)
	        	{
	        		sql = sql + " and id = " + custCriteria.getId();
	        	}
	            if ((!Util.getVal(custCriteria.getIdentification()).equals("") ))
	        	{
	            	sql = sql + " and identification like '%" + custCriteria.getIdentification() + "%'";
	        	}
	            if ((!Util.getVal(custCriteria.getName()).equals("") ))
	        	{
	            	sql = sql + " and name like '%" + custCriteria.getName() + "%'";
	        	}
	            if ((!custCriteria.getStreet().equals("") ))
	        	{
	            	sql = sql + " and street like '%" + custCriteria.getStreet() + "%'";
	        	}
	            if ((!Util.getVal(custCriteria.getSuburb()).equals("") ))
	        	{
	            	sql = sql + " and suburb like '%" + custCriteria.getSuburb() + "%'";
	        	}
	            if ((!Util.getVal(custCriteria.getState()).equals("") ))
	        	{
	            	sql = sql + " and state like '%" + custCriteria.getState() + "%'";
	        	}
	            if ((!Util.getVal(custCriteria.getPostcode()).equals("") ))
	        	{
	            	sql = sql + " and postcode like '%" + custCriteria.getPostcode() + "%'";
	        	}
	            if ((!Util.getVal(custCriteria.getGender()).equals("") ))
	        	{
	            	sql = sql + " and gender = '" + custCriteria.getGender() + "'";
	        	}
	            sql = sql + " order by id";
	            
	            System.out.println(sql);
	            
	            statement = connection.createStatement();
	            rs = statement.executeQuery(sql);
	     
	            while (rs.next()) {
	                customer = new Customer();
	                customer.setId(rs.getInt("id"));
	                customer.setIdentification(rs.getString("identification"));
	                customer.setName(rs.getString("name"));
	                customer.setStreet(rs.getString("street"));
	                customer.setSuburb(rs.getString("suburb"));
	                customer.setState(rs.getString("state"));
	                customer.setPostcode(rs.getString("postcode"));
	                customer.setGender(rs.getString("gender"));
	                customer.setDefaulter(rs.getString("defaulter"));
	                
	                System.out.println(customer.getName());
	                
	                //add each customer to the list
	                list.add(customer);
	                
	            }
	            
	        } 
	        catch(ClassNotFoundException e)
	        {
	            e.printStackTrace();
	        }
	        finally {
	            DbUtil.close(rs);
	            DbUtil.close(statement);
	            DbUtil.close(connection);
	        }
	        return list;
	}
	@Override
	public boolean markDefaulter(int id) {
		try {
			
			 connection = ConnectionFactory.getInstance().getConnection();
			 preparedStatement = connection.prepareStatement(MARK_DEFAULTER); 
			 preparedStatement.setString(1,Customer.DEFAULTER_YES );
			 preparedStatement.setInt(2, id);  
			 preparedStatement.executeUpdate();
		} 
		catch (SQLException e) {
        	return false;
        }
		catch(ClassNotFoundException e)
	        {
	            e.printStackTrace();
	        }
		
		finally {
            DbUtil.close(preparedStatement);
            DbUtil.close(connection);
        }
		return true;
	}
	
	
	@Override
	public boolean isFrequentCustomer(int id) throws SQLException {
		String sql = null;
		int lastYearStay = 0;
		boolean result = false;
		ResultSet rs = null;
		try {
		
			connection = ConnectionFactory.getInstance().getConnection();
			statement = connection.createStatement();
			
			sql = "SELECT DATEDIFF(departure,arrival) AS DiffDate" +
				  " from booking" + 
				  " where arrival >= DATE_SUB(NOW(),INTERVAL 2 YEAR)" +
				  " and customer_id = " + id;
		  
			System.out.println(sql);
		    rs = statement.executeQuery(sql);
            while (rs.next()) {
            	lastYearStay = lastYearStay + rs.getInt("DiffDate");
            }
            
            //System.out.println(lastYearStay);
            
            Customer cust = this.getCustomerByID(id);
            if (lastYearStay >= 14 && cust.isDefaulter() == false) 
		    {
        	    result = true;
		    }
           
        }
		catch(ClassNotFoundException e)
	        {
	            return false;
	        }
	       
		finally {
			DbUtil.close(rs);
            DbUtil.close(preparedStatement);
            DbUtil.close(connection);
        }
		return result;
	}	
  
	
}
