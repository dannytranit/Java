import java.sql.SQLException;
import java.util.List;

public interface CustomerManager {
	public abstract List<Customer> getAllCustomers() throws SQLException;
	public abstract Customer getCustomerByID(int id) throws SQLException;
	public abstract List<Customer> getCustomerByCriteria(Customer customer) throws SQLException;
	public abstract int createCustomer(Customer customer) throws SQLException;
	public abstract boolean updateCustomer(Customer customer);
	public abstract boolean deleteCustomer(int id);
	public abstract boolean markDefaulter(int id);
	public abstract boolean isFrequentCustomer(int id) throws SQLException;
}

