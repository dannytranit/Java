import java.util.ArrayList;

public class Customer {
	public static final String DEFAULTER_YES = "YES";
	private int id;
	private String identification;
	private String name;
	private String gender;
	private String street;
	private String suburb;
	private String state;
	private String postcode;
	private String address;
	private String defaulter;
	
	
	//public ArrayList<Rental> rentals = new ArrayList<Rental>();
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getIdentification() {
		return identification;
	}
	public void setIdentification(String identification) {
		this.identification = identification;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	
	public String getStreet() {
		return street;
	}
	
	public void setSuburb(String suburb) {
		this.suburb = suburb;
	}
	public String getSuburb() {
		return suburb;
	}
	
	public void setState(String state) {
		this.state = state;
	}
	public String getState() {
		return state;
	}
	
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getPostcode() {
		return postcode;
	}
	
	public String getAddress() {
		address = street + " " + suburb + " " + state + " " + postcode;
		return address;
	}
	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	
	public void setDefaulter(String defaulter) {
		this.defaulter = defaulter;
	}
	
	public String getDefaulter() {
		return this.defaulter ;
	}
	
	public boolean isDefaulter() {
		if (defaulter.equals(DEFAULTER_YES)){
		   return true;
		}
		return false;
	}
	
	//public void setGender(String gender) {
		//this.gender = gender;
	//}
	/*
	public ArrayList<Rental> getRentals() {
		return rentals;
	}
	public void setRentals(ArrayList<Rental> rentals) {
		this.rentals = rentals;
	}*/
	
	
	
	
}