import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;


public class UCDialog extends JDialog implements ActionListener{
	int customerId;
	String customerIdentification;
	String customerName;
	String customerStreet;
	String customerSuburb;
	String customerState;
	String customerPostcode;
	String customerGender;
 
	JTextField custIdentification;
	JTextField custName;
	JTextField custStreet;
	JTextField custSuburb;
	JTextField custState;
	JTextField custPostcode;
	 
	private JButton updateCustomer,closeWindow;
	JRadioButton rbMale, rbFemale;
	
	public UCDialog(int customerId,String customerIdentification, String customerName, String customerStreet,String customerSuburb,String customerState,String customerPostcode,String customerGender) {
		
		
		this.customerId = customerId;
		this.customerIdentification = customerIdentification;
		this.customerName = customerName;
		this.customerStreet = customerStreet;
		this.customerSuburb = customerSuburb;
		this.customerState = customerState;
		this.customerPostcode = customerPostcode;
		this.customerGender = customerGender;
		
		add(getPanel());
		
	    this.setModal(true);
		this.setSize(400,250);
    	this.setTitle("Edit Customer");
        this.setLocationRelativeTo(this);      	
    	this.setVisible(true); 
	}
	
	
	public JPanel getPanel(){
		JPanel panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		
		GridBagConstraints left = new GridBagConstraints();
        left.anchor = GridBagConstraints.EAST;
        
        GridBagConstraints right = new GridBagConstraints();
        right.weightx = 2.0;
        right.fill = GridBagConstraints.HORIZONTAL;
        right.gridwidth = GridBagConstraints.REMAINDER;
	    
        GridBagConstraints down = new GridBagConstraints();
        down.fill = GridBagConstraints.HORIZONTAL;
        down.gridx = 1;
        down.gridy = 10;
        down.weightx = 1.0; 
        down.weighty = 0.0;
      
		JLabel lblIdentification = new JLabel("Identification: ");
		panel.add(lblIdentification,left);
		
		custIdentification = new JTextField(customerIdentification,10);
		panel.add(custIdentification,right);
		
		JLabel lblName = new JLabel("Name:");
		panel.add(lblName,left);
		
		custName = new JTextField(customerName,10);
		panel.add(custName,right);
		
		
		JLabel lblStreet = new JLabel("Street: ");
		panel.add(lblStreet,left);
		
		custStreet = new JTextField(customerStreet,10);
		panel.add(custStreet,right);
		
		JLabel lblSuburb = new JLabel("Suburb: ");
		panel.add(lblSuburb,left);
		
		custSuburb = new JTextField(customerSuburb,10);
		panel.add(custSuburb,right);
		
		JLabel lblState = new JLabel("State: ");
		panel.add(lblState,left);
		
		custState = new JTextField(customerState,10);
		panel.add(custState,right);
		
		JLabel lblPostcode = new JLabel("Postcode: ");
		panel.add(lblPostcode,left);
		
		custPostcode = new JTextField(customerPostcode,10);
		panel.add(custPostcode,right);
		
		JLabel lblGender = new JLabel("Gender: ");
		panel.add(lblGender,left);
		
		
		Box horizontalBox = new Box(BoxLayout.X_AXIS);
		rbMale = new JRadioButton("Male");
		horizontalBox.add(rbMale);
		
		rbFemale = new JRadioButton("Female");
		horizontalBox.add(rbFemale);
		
		
		boolean selected = false;
		
		if(customerGender != null && !customerGender.isEmpty()){
			selected = customerGender.equals("Male")?true:false;
		}
		
		rbMale.setSelected(selected);
		rbFemale.setSelected(!selected);
		panel.add(horizontalBox);
		
		ButtonGroup bg = new ButtonGroup();
		bg.add(rbMale);
		bg.add(rbFemale);
		
		updateCustomer = new JButton("Update");
		panel.add(updateCustomer,down);
		updateCustomer.addActionListener(this);
    	
		return panel;
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		customerIdentification = custIdentification.getText();
		customerName = custName.getText();
		customerStreet = custStreet.getText();
		customerSuburb = custSuburb.getText();
		customerState = custState.getText();
		customerPostcode = custPostcode.getText();
		
		customerGender = (rbMale.isSelected())?"Male":"Female";
		Customer customer = new Customer();
		customer.setId(customerId);
		customer.setIdentification(customerIdentification);
		customer.setName(customerName);
		customer.setStreet(customerStreet);
		customer.setSuburb(customerSuburb);
		customer.setState(customerState);
		customer.setSuburb(customerSuburb);
		customer.setState(customerState);
		customer.setSuburb(customerSuburb);
		customer.setPostcode(customerPostcode);
		customer.setGender(customerGender);
		
		CustomerManagerImpl cdl = new CustomerManagerImpl();
		try {
			cdl.updateCustomer(customer);					
			this.dispose();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this,				 
				    "Customer not updated",
				    "ERROR.",
				    JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	}
}
