import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.*;
import javax.swing.*;


public class VCDialog extends JDialog implements ActionListener{
	int customerId;
	String customerIdentification;
	String customerName;
	String customerStreet;
	String customerSuburb;
	String customerState;
	String customerPostcode;
	String customerGender;
	String customerDefaulter;
 
	JTextField custIdentification;
	JTextField custName;
	JTextField custStreet;
	JTextField custSuburb;
	JTextField custState;
	JTextField custPostcode;
	JTextField custDefaulter;
	 
	private JButton closeWindow;
	
	JRadioButton rbMale, rbFemale, rbFreqCustYes,rbFreqCustNo;
	
	public VCDialog(int customerId,String customerIdentification, String customerName, String customerStreet,String customerSuburb,String customerState,String customerPostcode,String customerGender,String customerDefaulter) {
		
		this.customerId = customerId;
		this.customerIdentification = customerIdentification;
		this.customerName = customerName;
		this.customerStreet = customerStreet;
		this.customerSuburb = customerSuburb;
		this.customerState = customerState;
		this.customerPostcode = customerPostcode;
		this.customerGender = customerGender;
		this.customerDefaulter = customerDefaulter;
		
		add(getPanel());
		
	    this.setModal(true);
		this.setSize(400,300);
    	this.setTitle("View More Details");
        this.setLocationRelativeTo(this);      	
    	this.setVisible(true); 
	}
	
	
	public JPanel getPanel(){
		JFrame frame = new JFrame();
		JPanel panel = new JPanel();
	 try{
		
		panel.setLayout(new GridBagLayout());
		
		GridBagConstraints left = new GridBagConstraints();
        left.anchor = GridBagConstraints.EAST;
        
        GridBagConstraints right = new GridBagConstraints();
        right.weightx = 1.0;
        right.fill = GridBagConstraints.HORIZONTAL;
        right.gridwidth = GridBagConstraints.REMAINDER;
        
        GridBagConstraints down = new GridBagConstraints();
        down.fill = GridBagConstraints.HORIZONTAL;
        down.gridx = 2;
        down.gridy = 10;
        down.weightx = 1.0; 
        down.weighty = 0.0;
				
        //panel.setBackground(Color.green);
        //frame.getContentPane().add(panel);
        
        JLabel lblDefaulter = new JLabel("Defaulter: ");
		panel.add(lblDefaulter,left);
				 
		custDefaulter = new JTextField(customerDefaulter,10);
		if(customerDefaulter != null && !customerDefaulter.isEmpty()){
			custDefaulter.setBackground(Color.RED);
		}
		panel.add(custDefaulter,right);
		custDefaulter.setEditable(false);
		
		JLabel lblIdentification = new JLabel("Identification: ");
		panel.add(lblIdentification,left);
		
		custIdentification = new JTextField(customerIdentification,10);
		panel.add(custIdentification,right);
		custIdentification.setEditable(false);
		
		JLabel lblName = new JLabel("Name: ");
		panel.add(lblName,left);
		
		custName = new JTextField(customerName,10);
		panel.add(custName,right);
		custName.setEditable(false);
		
		JLabel lblStreet = new JLabel("Street: ");
		panel.add(lblStreet,left);
		
		custStreet = new JTextField(customerStreet,10);
		panel.add(custStreet,right);
		custStreet.setEditable(false);
		
		JLabel lblSuburb = new JLabel("Subburb: ");
		panel.add(lblSuburb,left);
		
		custSuburb = new JTextField(customerSuburb,10);
		panel.add(custSuburb,right);
		custSuburb.setEditable(false);
		
		JLabel lblState = new JLabel("State: ");
		panel.add(lblState,left);
		
		custState = new JTextField(customerState,10);
		panel.add(custState,right);
		custState.setEditable(false);
		
		JLabel lblPostcode = new JLabel("Postcode: ");
		panel.add(lblPostcode,left);
		
		custPostcode = new JTextField(customerPostcode,10);
		panel.add(custPostcode,right);
		custPostcode.setEditable(false);
		
		JLabel lblGender = new JLabel("Gender: ");
		panel.add(lblGender,left);
		
        
		Box horizontalBox = new Box(BoxLayout.X_AXIS);
		
		rbMale = new JRadioButton("Male");
		rbMale.setEnabled(false);
		horizontalBox.add(rbMale);
		
		rbFemale = new JRadioButton("Female");
		rbFemale.setEnabled(false);
		horizontalBox.add(rbFemale);
		
		boolean selected = false;
		
		if(customerGender != null && !customerGender.isEmpty()){
			selected = customerGender.equals("Male")?true:false;
		}
		
		rbMale.setSelected(selected);
		rbFemale.setSelected(!selected);
		panel.add(horizontalBox);
		
			
		CustomerManagerImpl cdl = new CustomerManagerImpl();
		
		JLabel lblFrequentCust = new JLabel("Frequent: ");
		panel.add(lblFrequentCust,left);
			
		Box horizontalBoxFreqC = new Box(BoxLayout.X_AXIS);
		rbFreqCustYes = new JRadioButton("Yes");
		rbFreqCustYes.setEnabled(false);
		horizontalBoxFreqC.add(rbFreqCustYes);
		
		rbFreqCustNo = new JRadioButton("No");
		rbFreqCustNo.setEnabled(false);
		horizontalBoxFreqC.add(rbFreqCustNo);
		
		selected = cdl.isFrequentCustomer(this.customerId);
		
		rbFreqCustNo.setSelected(!selected);
		rbFreqCustYes.setSelected(selected);
		
		panel.add(horizontalBoxFreqC);
		
		ButtonGroup bg = new ButtonGroup();
		bg.add(rbMale);
		bg.add(rbFemale);
		
		closeWindow = new JButton("Close");
		panel.add(closeWindow,down);
		closeWindow.addActionListener(this);
    
		}
		catch (Exception e) {
			JOptionPane.showMessageDialog(this,				 
				    "Check if customer is frequent has error!",
				    "ERROR.",
				    JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	 
		return panel;
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		this.dispose();
	}
}
